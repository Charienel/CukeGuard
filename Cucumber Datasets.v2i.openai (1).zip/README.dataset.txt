# Cucumber Datasets > 2026-09-14 11:28am
https://universe.roboflow.com/rafael-torrentira/cucumber-datasets-cu9z9

Provided by a Roboflow user
License: CC BY 4.0

